package main

import (
	"log"
	"os"
)

type Config struct {
	TelegramToken string
	TrelloKey     string
	TrelloToken   string
	BoardID       string
	ListBacklog   string
	ListProgress  string
}

func LoadConfig() *Config {
	c := &Config{
		TelegramToken: os.Getenv("TELEGRAM_TOKEN"),
		TrelloKey:     os.Getenv("TRELLO_KEY"),
		TrelloToken:   os.Getenv("TRELLO_TOKEN"),
		BoardID:       os.Getenv("BOARD_ID"),
		ListBacklog:   os.Getenv("LIST_BACKLOG_ID"),
		ListProgress:  os.Getenv("LIST_PROGRESS_ID"),
	}

	// Verificar
	if c.TelegramToken == "" || c.TrelloKey == "" || c.TrelloToken == "" {
		log.Fatal("Faltan variables de entorno.")
	}
	return c
}
