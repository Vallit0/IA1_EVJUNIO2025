# Manual Técnico

Este documento describe los pasos necesarios para instalar, configurar y ejecutar el proyecto **Telegram–Trello Bot** en Windows.

---

## 1. Requisitos Previos

1. **Go** ≥ 1.20 instalado  
   Descargar en: https://go.dev/dl/  
2. **MSYS2 + MinGW-w64** (para CGO y RobotGo)  
   - Instalar vía `winget install --id=MSYS2.MSYS2 -e`  
   - En terminal MSYS2 MinGW 64-bit:
     ```bash
     pacman -Syu
     pacman -S --noconfirm \
       mingw-w64-x86_64-toolchain \
       mingw-w64-x86_64-libpng \
       mingw-w64-x86_64-zlib \
       mingw-w64-x86_64-pkg-config
     ```
   - Añadir `C:\msys64\mingw64\bin` al `PATH` de Windows  
3. **Git** instalado  
   Descargar en: https://git-scm.com/download/win  

---

## 2. Clonar el Repositorio

```powershell
git clone https://github.com/tu-usuario/telegram-trello-bot.git
cd telegram-trello-bot
```

---

## 3. Variables de Entorno

Crear un archivo `.env` en la raíz del proyecto con el siguiente contenido:

```env
# Telegram
TELEGRAM_TOKEN=********

# Trello API
TRELLO_KEY=****************
TRELLO_TOKEN=****************

# Identificadores de Trello
BOARD_ID=hLYmmH0O
LIST_BACKLOG_ID=********
LIST_PROGRESS_ID=********
```

La carga de variables de entorno se realiza automáticamente en la función `init()` de `main.go` mediante `github.com/joho/godotenv`.

---

## 4. Inicializar el Módulo y Dependencias

```powershell
go mod init telegram-trello-bot
go get github.com/joho/godotenv@latest
go mod tidy
```

Dependencias principales:

- `github.com/go-telegram-bot-api/telegram-bot-api`
- `github.com/adlio/trello`
- `github.com/go-vgo/robotgo`
- `github.com/joho/godotenv`

---

## 5. Compilar el Ejecutable

Asegúrate de que Go use CGO:

```powershell
go env -w CGO_ENABLED=1
go build -o bot.exe
```

---

## 6. Ejecutar el Bot

```powershell
.\bot.exe
```

Si todo está correcto, verás en consola:

```plaintext
2025/06/25 20:05:24 Bot listo: @MiTrelloBot_bot
```

El bot queda a la espera de comandos en Telegram.