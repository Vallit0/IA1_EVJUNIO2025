package main

import (
	"fmt"
	"log"
	"strings"
	"time"

	"github.com/adlio/trello"
	tgbotapi "github.com/go-telegram-bot-api/telegram-bot-api"
	"github.com/go-vgo/robotgo"
	"github.com/joho/godotenv"
)

func init() {
	if err := godotenv.Load(); err != nil {
		log.Println("No .env file found, relying on real environment variables")
	}
}

func main() {
	cfg := LoadConfig()

	// Inicializar cliente Trello
	client := trello.NewClient(cfg.TrelloKey, cfg.TrelloToken)

	// Inicializar bot Telegram
	bot, err := tgbotapi.NewBotAPI(cfg.TelegramToken)
	if err != nil {
		log.Panic(err)
	}
	log.Printf("Bot listo: %s", bot.Self.UserName)

	u := tgbotapi.NewUpdate(0)
	u.Timeout = 60
	updates, _ := bot.GetUpdatesChan(u)

	for update := range updates {
		if update.Message == nil || !update.Message.IsCommand() {
			continue
		}

		switch update.Message.Command() {

		case "listar":
			// 1) Obtener la lista
			list, err := client.GetList(cfg.ListBacklog, trello.Defaults())
			if err != nil {
				bot.Send(tgbotapi.NewMessage(update.Message.Chat.ID,
					"Error al obtener la lista Backlog."))
				continue
			}
			// 2) Traer todas las tarjetas de esa lista

			// 3) Formatear la respuesta
			if len(cards) == 0 {
				bot.Send(tgbotapi.NewMessage(update.Message.Chat.ID,
					"No hay historias en Backlog."))
				continue
			}
			var sb strings.Builder
			sb.WriteString("*Historias en Backlog:*\n")
			for _, c := range cards {
				sb.WriteString(fmt.Sprintf("• %s (ID: `%s`)\n", c.Name, c.ID))
			}
			msg := tgbotapi.NewMessage(update.Message.Chat.ID, sb.String())
			msg.ParseMode = "Markdown"
			bot.Send(msg)

		case "historia":
			title := update.Message.CommandArguments()
			card := trello.Card{
				Name:   title,
				IDList: cfg.ListBacklog,
			}
			// Agregar codigo aqui
		case "mover":
			args := update.Message.CommandArguments() // e.g. "Root - chmod (En Proceso)"

			// 1) Extraer nombre y destino entre paréntesis
			idx := strings.LastIndex(args, "(")
			if idx == -1 || !strings.HasSuffix(args, ")") {
				bot.Send(tgbotapi.NewMessage(update.Message.Chat.ID,
					"Formato inválido. Usa: /mover <nombre de tarjeta> (<nombre de lista>)"))
				continue
			}
			cardName := strings.TrimSpace(args[:idx])
			listName := strings.TrimSpace(args[idx+1 : len(args)-1]) // quita paréntesis

			// 2) Buscar la tarjeta en Backlog
			backlog, err := client.GetList(cfg.ListBacklog, trello.Defaults())
			if err != nil {
				bot.Send(tgbotapi.NewMessage(update.Message.Chat.ID, "Error al leer Backlog"))
				continue
			}
			cards, err := backlog.GetCards(trello.Defaults())
			if err != nil {
				bot.Send(tgbotapi.NewMessage(update.Message.Chat.ID, "Error al obtener tarjetas"))
				continue
			}
			var target *trello.Card
			for i := range cards {
				if cards[i].Name == cardName || strings.HasPrefix(cards[i].Name, cardName) {
					target = cards[i]
					break
				}
			}
			if target == nil {
				bot.Send(tgbotapi.NewMessage(update.Message.Chat.ID,
					fmt.Sprintf("No encontré ninguna tarjeta que empiece por '%s'", cardName)))
				continue
			}

			// 3) Resolver dinámicamente el ID de la lista destino
			board, err := client.GetBoard(cfg.BoardID, trello.Defaults())
			if err != nil {
				bot.Send(tgbotapi.NewMessage(update.Message.Chat.ID, "Error al leer el tablero"))
				continue
			}
			lists, err := board.GetLists(trello.Defaults())
			if err != nil {
				bot.Send(tgbotapi.NewMessage(update.Message.Chat.ID, "Error al obtener listas"))
				continue
			}
			var destID string
			for _, l := range lists {
				if l.Name == listName {
					destID = l.ID
					break
				}
			}
			if destID == "" {
				bot.Send(tgbotapi.NewMessage(update.Message.Chat.ID,
					fmt.Sprintf("Lista '%s' no existe en este tablero", listName)))
				continue
			}

			// 4) Mover la tarjeta
			if err := target.MoveToList(destID); err != nil {
				bot.Send(tgbotapi.NewMessage(update.Message.Chat.ID, "Error moviendo la tarjeta"))
			} else {
				bot.Send(tgbotapi.NewMessage(update.Message.Chat.ID,
					fmt.Sprintf("Tarjeta '%s' movida a '%s'", target.Name, listName)))
			}

		case "iniciar_daily":
			// 1) Abrir Trello

			time.Sleep(5 * time.Second)

			if err != nil {
				log.Println("Error al capturar pantalla:", err)
			} else {

				filename := fmt.Sprintf("screenshot_%s.png", time.Now().Format("2006-01-02"))
				robotgo.Save(img, filename)
				log.Println("Screenshot guardada en:", filename)
			}

			card := trello.Card{
				Name:   fmt.Sprintf("Daily iniciado – %s", time.Now().Format("2006-01-02")),
				IDList: cfg.ListBacklog,
			}
			if err := client.CreateCard(&card, trello.Defaults()); err != nil {
				bot.Send(tgbotapi.NewMessage(update.Message.Chat.ID, "Error creando tarjeta de daily."))
			} else {
				bot.Send(tgbotapi.NewMessage(update.Message.Chat.ID, "Daily iniciado correctamente."))
			}

		default:
			bot.Send(tgbotapi.NewMessage(update.Message.Chat.ID, "Comando no reconocido."))
		}
	}
}
